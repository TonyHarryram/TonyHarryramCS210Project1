#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define byte unsigned char
#define word unsigned short
byte code[0x10000];
byte data[0x10000];
byte stack[0x10000];

void RotateLeft( unsigned char* value, int shift , unsigned short* IP) {
	*IP+=1;
    if ((shift &= sizeof(value)*8 - 1) == 0)
      { value == value;}
	else
    *value = ( (int)*value << shift) | ((int)*value >> (sizeof(value)*8 - shift));
}

void interrupt(char* value , unsigned short* IP){
	*IP+=1;
	if( value[0] == '2' && value[1] == '0'){ printf(" End Of Code Reached. \n");exit(0);}
	

}

void addrtrm( unsigned char* reg1 , unsigned char reg2 , unsigned short* IP){
	*IP+=1;
	*reg1 += reg2;
}

void movrti(unsigned char* reg , char* value , unsigned short* IP){
	*IP+=1; 
	*reg = ((value[0] + value[1]) - 96 );
 }
void datatohex (const void* indata , size_t insize , char* outstring , size_t outsize){
	size_t i, j;
	j = 0;
	for( i = 0 ; i < insize ; ++i){
		sprintf( (char*)(outstring+j) , "%02X" ,((unsigned char*)indata)[i]);
		j+=2;
	}


}
void DumpHex(const void* data, size_t size) {
	char ascii[17];
	size_t i, j;
	ascii[16] = '\0';
	for (i = 0; i < size; ++i) {
		printf("%02X ", ((unsigned char*)data)[i]);
		if (((unsigned char*)data)[i] >= ' ' && ((unsigned char*)data)[i] <= '~') {
			ascii[i % 16] = ((unsigned char*)data)[i];
		} else {
			ascii[i % 16] = '.';
		}
		if ((i+1) % 8 == 0 || i+1 == size) {
			printf(" ");
			if ((i+1) % 16 == 0) {
				printf("|  %s \n", ascii);
			} else if (i+1 == size) {
				ascii[(i+1) % 16] = '\0';
				if ((i+1) % 16 <= 8) {
					printf(" ");
				}
				for (j = (i+1) % 16; j < 16; ++j) {
					printf("   ");
				}
				printf("|  %s \n", ascii);
			}
		}
	}
}

int main(void){
	//Initalizing Varibles
	int len;
	int spacer = 0;
	byte AL,AH,BL,BH,CL,CH,DL,DH;
	word AX,BX,CX,DX;
	word IP,ZF,CF,OF,SF,SP;
	word CS,DS;
	//Checking for the file integrity
	FILE *fopen(), *fp;
	fp = fopen("Test.COM" , "r");
	if(!fp){printf("File Read Error\n") ; return -1;}

	char fstring[sizeof(fp) * 3 ] ; //For some reason this string needs to be 3x larger than the sizeof(fp) in order to get all the data
	char hare[48]; //String Used for storing the Hex data of fstring
	char cinstruct[2] = "00";
	char tinstruct[2] = "00";
	for( int i = 0 ; i < sizeof(fp) * 3  ; i++){
		fstring[i] = getc(fp); //Puts the data of BUP.com inside of the string
		code[0x100 + i] = fstring[i];
	}
	fclose(fp); //Closes file since all the data is now in fstring
	datatohex( &fstring , sizeof(fstring) , hare , sizeof(hare)); //Puts all the Hex data in a literal string
	
	//Initalizing the relevant pointers,flags, and registers.
	IP = 0x100;
	SP = 0xFFFE;
	AX = 0x1000;
	AL = 0x00;
	ZF = 0x00;
	SF = 0x00;
	CF = 0x00;
	OF = 0x00;
	byte codebyte;
	printf("\n");
	for( int i = 0 ; i<24 ; i++){
		//cinstruct stores the current opcode and tinstruct stores the one after for use in two byte instructions
		cinstruct[0] = hare[i];
		cinstruct[1] = hare[i+1];
		tinstruct[0] = hare[i+2];
		tinstruct[1] = hare[i+3];
		codebyte = code[0x100 + IP];

		//Identifies which case the current instruction is and executes the appropiate function
		if( cinstruct[0] == 'B' && cinstruct[1] == '0' ){ printf("  B0 Reached. ") ; movrti(&AL , tinstruct , &IP); i+=2;}
		if( cinstruct[0] == '0' && cinstruct[1] == '1' ){ printf(" 01 Reached. ") ; }
		if( cinstruct[0] == 'C' && cinstruct[1] == '0' ){ printf(" C0 Reached. ") ; RotateLeft(&AL , 1 , &IP); }
		if( cinstruct[0] == 'C' && cinstruct[1] == 'D' ){ printf(" CD Reached. ") ; interrupt(tinstruct , &IP); }
		if( cinstruct[0] == '0' && cinstruct[1] == '2' ){ printf(" 02 Reached. ") ; addrtrm(&AL , AL , &IP);}
		if( cinstruct[0] == '2' && cinstruct[1] == '0' ){ printf(" End Reached. ") ; }
		if((int)AL == 128){SF = 1;} else SF = 0x00;
		if((int)AL == 0){  OF = ZF = CF = 1 ; SF = 0;}
		//Printing the Registers and flags after the instructions are executed
		printf(" AL:%02X IP:%02X ZF:%02X SF:%02X CF:%02X OF:%02X\n " , AL , IP , ZF , SF , CF , OF);
		i += 1;
	}





    return 0 ; 
}